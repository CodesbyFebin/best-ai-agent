#!/usr/bin/env python3
"""Portfolio gate for BestAIAgent.in content registries."""
import argparse,json,re,sys
from collections import Counter
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument("--registry",required=True);ap.add_argument("--report",default="registry-report.json");a=ap.parse_args();d=json.loads(Path(a.registry).read_text());pages=d.get("pages",[])
def dup(field):return sorted(k for k,v in Counter(p.get(field) for p in pages).items() if k and v>1)
errors={"duplicateTitles":dup("title"),"duplicateCanonicals":dup("canonical"),"duplicateKeywords":dup("primaryKeyword"),"appUrls":[p.get("canonical") for p in pages if "/app/" in p.get("canonical","")],"placeholders":[p.get("canonical") for p in pages if re.search(r"\b(TODO|TBD|lorem ipsum|coming soon)\b",json.dumps(p),re.I)],"orphans":[p.get("canonical") for p in pages if not p.get("internalLinks")]}
report={"valid":not any(errors.values()),"pages":len(pages),"errors":errors};Path(a.report).write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));sys.exit(0 if report["valid"] else 4)
