#!/usr/bin/env python3
import argparse,datetime as dt,hashlib,json,re,sys
from pathlib import Path
def validate(p,profile):
 claims=p.get("claims",[]);sources={s["id"]:s for s in p.get("sources",[])};ptype=p.get("pageType");rules=profile["publicationRules"];reasons=[];gates=[]
 def gate(name,passed,why=(),blocking=True):gates.append({"gate":name,"passed":bool(passed),"blocking":blocking,"reasons":list(why)})
 material=[c for c in claims if c.get("material",True)];unsupported=[c["id"] for c in material if c.get("confidence",0)<rules["minimumClaimConfidence"] or not c.get("evidenceIds") or any(x not in sources for x in c.get("evidenceIds",[]))]
 gate("material-claims-supported",not unsupported,unsupported)
 auth=[s for s in sources.values() if s.get("authorityTier") in {"primary","authoritative"}];gate("source-authority",len(auth)>=rules["minimumAuthoritativeSources"],[] if len(auth)>=rules["minimumAuthoritativeSources"] else [f"{rules['minimumAuthoritativeSources']} authoritative sources required"])
 canonical=p.get("canonical","");canonical_ok=canonical.startswith(f"https://{profile['domain']}/") and "/app/" not in canonical;gate("canonical",canonical_ok,[] if canonical_ok else ["Canonical must use the configured domain and cannot contain /app/"])
 volatile=[c["id"] for c in claims if c.get("volatile") and (not c.get("verifiedAt") or (dt.date.today()-dt.date.fromisoformat(c["verifiedAt"])).days>rules["volatileEvidenceMaxAgeDays"])];gate("volatile-evidence-fresh",not volatile,volatile)
 invented=[x for x in p.get("integrations",[]) if not x.get("evidenceIds")];gate("integrations-evidenced",not invented,[x.get("name","unknown") for x in invented])
 links=p.get("internalLinks",[]);links_ok=len(links)>=rules["minimumInternalLinks"];gate("internal-links",links_ok,[] if links_ok else [f"{rules['minimumInternalLinks']} internal links required"])
 required=profile["pageTypeRequirements"].get(ptype,{});verified=sum(c.get("status")=="verified" for c in claims);minimums_ok=verified>=required.get("verifiedClaims",1) and len(sources)>=required.get("sources",2);gate("page-type-minimums",minimums_ok,[] if minimums_ok else [f"{ptype} requires {required.get('verifiedClaims',1)} verified claims and {required.get('sources',2)} sources"])
 approved=bool(p.get("approvedBy"));gate("human-approval",approved,[] if approved else ["Editorial approval missing"])
 publishable=all(g["passed"] for g in gates if g["blocking"]);return{"publishable":publishable,"profile":profile["id"],"pageType":ptype,"gates":gates,"summary":{"claims":len(claims),"sources":len(sources),"verifiedClaims":verified,"blockingFailures":sum(not g["passed"] and g["blocking"] for g in gates)},"contentHash":hashlib.sha256(json.dumps(p,sort_keys=True).encode()).hexdigest()}
ap=argparse.ArgumentParser(prog="safe-deep");ap.add_argument("--package",required=True);ap.add_argument("--profile",required=True);ap.add_argument("--report",default="quality-report.json");a=ap.parse_args();r=validate(json.loads(Path(a.package).read_text()),json.loads(Path(a.profile).read_text()));Path(a.report).write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));sys.exit(0 if r["publishable"] else 3)
