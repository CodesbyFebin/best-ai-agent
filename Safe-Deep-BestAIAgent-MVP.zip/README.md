# Safe-Deep Generator™ — MCPserver.in production MVP
Evidence-first research → claim ledger → draft → deterministic gates → approved export.

```bash
npm run dev
node cli/safe-deep.mjs --brief config/mcpserver.in.json --out output
python3 python/safe_deep.py --package examples/mcpserver-in/package.json
```
The validator exits 3 by design: the example contains one unsupported infrastructure claim and lacks editorial approval, proving the publishing gate blocks unsafe output.
