# Agent contracts
Research planner emits queries; retriever emits immutable source snapshots; analyst emits entities and contradictions; reviewer emits evidence-linked claim decisions; SEO strategist emits an intent blueprint; composer may use only verified material claims; controller emits gates; publisher refuses blocked or unapproved packages. Structured JSON is the inter-agent protocol.
