# Safe-Deep Generator — architecture
Safe-Deep is an evidence pipeline, not a prompt wrapper.

## Planes
1. Control: projects, briefs, policies, ownership, approvals.
2. Research: query planning, safe retrieval, immutable source snapshots, authority and contradiction analysis.
3. Claims: atomic claims linked to evidence with confidence and reviewer decisions.
4. Composition: intent blueprint, draft, internal links, metadata, schema and exports.
5. Assurance: deterministic blocking gates plus human review.
6. Delivery: Markdown, HTML, JSON-LD, draft-only WordPress, Git and signed webhook adapters.
7. Learning: analytics proposes refresh jobs; it never silently rewrites published content.

## Invariants
- Material claims need evidence IDs and confidence ≥75.
- Discovery sources cannot independently verify a claim.
- Failed blocking gates force `publishable=false`.
- First publication requires human approval.
- Authentication and ownership are resolved server-side.
- External writes are idempotent, logged and draft-first.

## Production repository
`app/` dashboard/API; `cli/` TypeScript CLI; `python/` validator/workers; `config/` domain profiles; `examples/` publishing packages; future `db/` Postgres schema and `workers/` queues.

## SaaS target
Next.js dashboard, FastAPI orchestration, PostgreSQL + pgvector, Redis/Celery queues, S3-compatible evidence storage, OIDC authentication, policy-scoped publishing credentials and OpenTelemetry.

## Core data
Project → Run → Source snapshots → Claims/evidence → Draft artifacts → Gate results → Approval → Publication receipt. Jobs have leases, attempts, exponential backoff and a dead-letter state.

## Security
Safe fetcher blocks private/link-local targets and caps redirects, bytes and time. Retrieved pages are untrusted data. Secrets remain outside prompts and artifacts. Publisher adapters cannot bypass approval gates.
