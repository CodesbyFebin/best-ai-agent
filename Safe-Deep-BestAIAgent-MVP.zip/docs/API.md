# API specification
`POST /v1/runs` creates a run from keyword, topic, domain, industry, audience, location, intent and language.
`GET /v1/runs/{id}` returns stage progress.
`POST /v1/runs/{id}/sources` attaches content-addressed evidence.
`POST /v1/runs/{id}/claims` creates claim-ledger records.
`POST /v1/runs/{id}/validate` runs deterministic gates.
`POST /v1/runs/{id}/approve` records editorial approval.
`POST /v1/runs/{id}/publish` requires ownership, a passing package and idempotency key.

All write endpoints authenticate server-side, enforce project ownership and emit audit events.
