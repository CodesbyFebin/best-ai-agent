# BestAIAgent.in functional profile

Positioning: **The independent authority for discovering, comparing and deploying AI agents.**

The profile supports agent, review, comparison, ranking, category, use-case, industry, framework, MCP server, integration, pricing, alternative, benchmark, research, guide, tutorial and glossary packages.

## Generate and validate

```bash
node cli/safe-deep.mjs generate \
  --profile config/bestaiagent.in.json \
  --seed seeds/bestaiagent/ai-coding-agents.json \
  --out output/bestaiagent/ai-coding-agents

python3 python/safe_deep.py \
  --package output/bestaiagent/ai-coding-agents/package.json \
  --profile config/bestaiagent.in.json \
  --report output/bestaiagent/ai-coding-agents/quality-report.json
```

The validator blocks unsupported or stale volatile claims, unevidenced integrations, invalid canonicals, weak page-type evidence, insufficient internal links and missing approval.

Validate a publication registry before a batch:

```bash
python3 python/validate_registry.py \
  --registry data/bestaiagent/launch-registry.json \
  --report output/bestaiagent/registry-report.json
```

This blocks duplicate titles, keywords and canonicals, `/app/` URLs, placeholders and orphan pages.
