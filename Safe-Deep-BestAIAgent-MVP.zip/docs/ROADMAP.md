# Roadmap
Phase 0: dashboard, CLIs, claim ledger, gates, MCPserver.in package.
Phase 1: safe search/retrieval, content hashes, contradiction and entity graph.
Phase 2: Ollama/cloud model router, section composition, citations and draft adapters.
Phase 3: Postgres/pgvector, Redis queues, organizations/RBAC, analytics refresh proposals.
Phase 4: multilingual evidence localization, policy packs, SSO and evaluation datasets.
